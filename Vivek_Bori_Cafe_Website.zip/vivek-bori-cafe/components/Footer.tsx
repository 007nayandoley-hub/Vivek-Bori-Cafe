import Link from "next/link";
import { MapPin, Phone, Clock, Coffee } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2 font-display text-lg font-semibold text-ivory">
            <Coffee size={18} className="text-gold" aria-hidden="true" />
            Vivek Bori Cafe
          </div>
          <p className="mt-3 max-w-xs text-sm text-stone">
            Specialty coffee and honest food, made for slow mornings and good
            company.
          </p>
        </div>

        <div className="space-y-3 text-sm text-stone">
          <p className="flex items-center gap-2">
            <Phone size={16} className="text-gold" aria-hidden="true" />
            +91 60018 87283
          </p>
          <p className="flex items-center gap-2">
            <MapPin size={16} className="text-gold" aria-hidden="true" />
            [Business address pending]
          </p>
          <p className="flex items-center gap-2">
            <Clock size={16} className="text-gold" aria-hidden="true" />
            Open Daily · 8:00 AM – 10:00 PM
          </p>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          {[
            { href: "/menu", label: "Menu" },
            { href: "/gallery", label: "Gallery" },
            { href: "/contact", label: "Reserve a Table" },
          ].map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="focus-ring text-stone transition-colors hover:text-gold"
            >
              {l.label}
            </Link>
          ))}
        </div>
      </div>

      <div className="border-t border-white/5 py-5 text-center text-xs text-stone/70">
        © {new Date().getFullYear()} Vivek Bori Cafe. Built by N9ne — Build.
        Automate. Scale.
      </div>
    </footer>
  );
}
