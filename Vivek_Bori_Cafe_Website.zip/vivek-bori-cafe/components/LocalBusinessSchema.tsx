export default function LocalBusinessSchema() {
  const data = {
    "@context": "https://schema.org",
    "@type": "CafeOrCoffeeShop",
    name: "Vivek Bori Cafe",
    image: "https://[DOMAIN_PENDING]/images/cafe-exterior.jpg",
    telephone: "+91-6001887283",
    servesCuisine: "Cafe, Coffee, Breakfast",
    priceRange: "₹₹",
    address: {
      "@type": "PostalAddress",
      streetAddress: "[Business address pending]",
      addressCountry: "IN",
    },
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: [
        "Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday",
      ],
      opens: "08:00",
      closes: "22:00",
    },
    // acceptsReservations left as string until a real booking system exists —
    // currently reservations happen via WhatsApp only.
    acceptsReservations: "https://wa.me/916001887283",
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
