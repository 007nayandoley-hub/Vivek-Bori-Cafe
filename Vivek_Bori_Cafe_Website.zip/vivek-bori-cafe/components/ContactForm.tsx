"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2, "Please enter your name"),
  phone: z.string().min(10, "Enter a valid phone number"),
  date: z.string().min(1, "Pick a date"),
  guests: z.string().min(1, "How many guests?"),
  message: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  async function onSubmit(data: FormData) {
    // TODO: wire to booking/notification backend before go-live.
    await new Promise((r) => setTimeout(r, 600));
    console.log("Reservation request:", data);
    setSubmitted(true);
    reset();
  }

  if (submitted) {
    return (
      <div
        role="status"
        className="rounded-xl border border-gold/30 bg-surface p-6 text-ivory"
      >
        <p className="font-display text-lg font-semibold">Request sent</p>
        <p className="mt-2 text-sm text-stone">
          We've got your details — we'll confirm your table over WhatsApp or
          phone shortly.
        </p>
        <button
          className="focus-ring mt-4 text-sm text-gold hover:underline"
          onClick={() => setSubmitted(false)}
        >
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      <div>
        <label htmlFor="name" className="mb-1.5 block text-sm text-stone">
          Name
        </label>
        <input
          id="name"
          {...register("name")}
          className="focus-ring w-full rounded-lg border border-white/10 bg-charcoal px-4 py-3 text-ivory placeholder:text-stone/50"
          placeholder="Your name"
        />
        {errors.name && (
          <p className="mt-1 text-xs text-amber">{errors.name.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="phone" className="mb-1.5 block text-sm text-stone">
          Phone number
        </label>
        <input
          id="phone"
          {...register("phone")}
          className="focus-ring w-full rounded-lg border border-white/10 bg-charcoal px-4 py-3 text-ivory placeholder:text-stone/50"
          placeholder="For confirming your table"
        />
        {errors.phone && (
          <p className="mt-1 text-xs text-amber">{errors.phone.message}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="date" className="mb-1.5 block text-sm text-stone">
            Date
          </label>
          <input
            id="date"
            type="date"
            min={new Date().toISOString().split("T")[0]}
            {...register("date")}
            className="focus-ring w-full rounded-lg border border-white/10 bg-charcoal px-4 py-3 text-ivory"
          />
          {errors.date && (
            <p className="mt-1 text-xs text-amber">{errors.date.message}</p>
          )}
        </div>
        <div>
          <label htmlFor="guests" className="mb-1.5 block text-sm text-stone">
            Guests
          </label>
          <input
            id="guests"
            type="number"
            min={1}
            {...register("guests")}
            className="focus-ring w-full rounded-lg border border-white/10 bg-charcoal px-4 py-3 text-ivory"
            placeholder="2"
          />
          {errors.guests && (
            <p className="mt-1 text-xs text-amber">{errors.guests.message}</p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm text-stone">
          Message (optional)
        </label>
        <textarea
          id="message"
          {...register("message")}
          rows={3}
          className="focus-ring w-full rounded-lg border border-white/10 bg-charcoal px-4 py-3 text-ivory placeholder:text-stone/50"
          placeholder="Any special requests?"
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="focus-ring w-full rounded-full bg-gold px-6 py-3 text-sm font-semibold text-charcoal transition-transform hover:scale-[1.02] disabled:opacity-60"
      >
        {isSubmitting ? "Sending…" : "Request Reservation"}
      </button>
    </form>
  );
}
