import ContactForm from "@/components/ContactForm";
import { MapPin, Phone, Clock } from "lucide-react";

export default function ContactPageClient() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <p className="text-sm uppercase tracking-[0.2em] text-gold">Visit us</p>
      <h1 className="mt-2 font-display text-4xl font-semibold text-ivory">
        Reserve a table
      </h1>

      <div className="mt-10 grid gap-12 md:grid-cols-2">
        <div>
          <ContactForm />
        </div>

        <div className="space-y-6">
          {/* Replace with real Google Maps embed once business address is confirmed */}
          <div className="flex aspect-video items-center justify-center rounded-xl border border-white/5 bg-surface text-stone">
            <div className="flex items-center gap-2 text-sm">
              <MapPin size={18} className="text-gold" aria-hidden="true" />
              Google Maps — pending business address
            </div>
          </div>

          <div className="space-y-4 rounded-xl border border-white/5 bg-surface p-6">
            <p className="flex items-center gap-3 text-sm text-stone">
              <Phone size={16} className="text-gold" aria-hidden="true" />
              +91 60018 87283
            </p>
            <p className="flex items-center gap-3 text-sm text-stone">
              <MapPin size={16} className="text-gold" aria-hidden="true" />
              [Business address pending]
            </p>
            <p className="flex items-center gap-3 text-sm text-stone">
              <Clock size={16} className="text-gold" aria-hidden="true" />
              Open Daily · 8:00 AM – 10:00 PM
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
