import { ImageIcon } from "lucide-react";

/**
 * Stand-in visual until real cafe photography is supplied.
 * Swap for <Image src="/images/..." /> once assets arrive —
 * see README "Replacing Placeholder Images".
 */
export default function PlaceholderImage({
  label,
  className = "",
}: {
  label: string;
  className?: string;
}) {
  return (
    <div
      role="img"
      aria-label={label}
      className={`flex flex-col items-center justify-center gap-2 border border-white/5 bg-gradient-to-br from-surface to-charcoal text-stone ${className}`}
    >
      <ImageIcon size={28} className="text-gold/50" aria-hidden="true" />
      <span className="px-4 text-center text-xs uppercase tracking-wide text-stone/70">
        {label}
      </span>
    </div>
  );
}
