import { MessageCircle } from "lucide-react";

// WhatsApp deep link — Client requirement: WhatsApp "Book a Table" CTA
const WHATSAPP_NUMBER = "916001887283";
const MESSAGE = encodeURIComponent(
  "Hi! I'd like to book a table at Vivek Bori Cafe."
);

export default function WhatsAppButton() {
  return (
    <a
      href={`https://wa.me/${WHATSAPP_NUMBER}?text=${MESSAGE}`}
      target="_blank"
      rel="noopener noreferrer"
      className="focus-ring fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-gold px-5 py-3 text-sm font-semibold text-charcoal shadow-lg shadow-black/40 transition-transform hover:scale-105"
      aria-label="Book a table on WhatsApp"
    >
      <MessageCircle size={18} aria-hidden="true" />
      Book a Table
    </a>
  );
}
