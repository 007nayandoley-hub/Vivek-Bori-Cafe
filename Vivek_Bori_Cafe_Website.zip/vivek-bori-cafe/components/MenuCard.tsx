export interface MenuItem {
  name: string;
  desc: string;
  price: string;
}

export default function MenuCard({ item }: { item: MenuItem }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-white/5 py-4">
      <div>
        <h3 className="font-display text-base font-semibold text-ivory">
          {item.name}
        </h3>
        <p className="mt-1 text-sm text-stone">{item.desc}</p>
      </div>
      <span className="whitespace-nowrap font-medium text-gold">
        {item.price}
      </span>
    </div>
  );
}
