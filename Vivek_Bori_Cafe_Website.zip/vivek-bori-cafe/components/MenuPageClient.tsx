"use client";

import { useState } from "react";
import MenuCard, { MenuItem } from "@/components/MenuCard";

const categories: Record<string, MenuItem[]> = {
  Coffee: [
    { name: "Filter Coffee", desc: "Slow-brewed, single origin.", price: "₹120" },
    { name: "Cold Brew", desc: "18-hour steeped, served over ice.", price: "₹160" },
    { name: "Cappuccino", desc: "Double shot, steamed milk foam.", price: "₹150" },
    { name: "Flat White", desc: "Velvety microfoam, strong espresso base.", price: "₹160" },
  ],
  Food: [
    { name: "Bori Breakfast", desc: "Eggs, toast, house chutney.", price: "₹220" },
    { name: "Avocado Toast", desc: "Sourdough, chili flakes, lime.", price: "₹210" },
    { name: "Grilled Sandwich", desc: "Cheese, veggies, herb butter.", price: "₹180" },
  ],
  Specials: [
    { name: "Affogato", desc: "Vanilla gelato drowned in espresso.", price: "₹190" },
    { name: "Cafe Signature Brew", desc: "Ask your barista — changes weekly.", price: "₹200" },
  ],
};

export default function MenuPageClient() {
  const [active, setActive] = useState("Coffee");

  return (
    <section className="mx-auto max-w-4xl px-6 py-20">
      <p className="text-sm uppercase tracking-[0.2em] text-gold">Menu</p>
      <h1 className="mt-2 font-display text-4xl font-semibold text-ivory">
        What we're serving
      </h1>

      <div
        role="tablist"
        aria-label="Menu categories"
        className="mt-8 flex gap-2 border-b border-white/5"
      >
        {Object.keys(categories).map((cat) => (
          <button
            key={cat}
            id={`tab-${cat}`}
            role="tab"
            aria-selected={active === cat}
            aria-controls={`panel-${cat}`}
            onClick={() => setActive(cat)}
            className={`focus-ring -mb-px border-b-2 px-4 py-3 text-sm font-medium transition-colors ${
              active === cat
                ? "border-gold text-gold"
                : "border-transparent text-stone hover:text-ivory"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div
        role="tabpanel"
        id={`panel-${active}`}
        aria-labelledby={`tab-${active}`}
        className="mt-6"
      >
        {categories[active].map((item) => (
          <MenuCard key={item.name} item={item} />
        ))}
      </div>
    </section>
  );
}
