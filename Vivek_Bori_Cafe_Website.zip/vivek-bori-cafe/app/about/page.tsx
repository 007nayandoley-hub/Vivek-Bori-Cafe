import type { Metadata } from "next";
import PlaceholderImage from "@/components/PlaceholderImage";

export const metadata: Metadata = {
  title: "Our Story",
  description:
    "Built on slow mornings and honest coffee. Learn what makes Vivek Bori Cafe different.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <section className="px-6 py-20">
      <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
        <PlaceholderImage
          label="Founder / team photo"
          className="aspect-[4/5] w-full rounded-2xl"
        />
        <div>
          <p className="text-sm uppercase tracking-[0.2em] text-gold">
            Our story
          </p>
          <h1 className="mt-2 font-display text-4xl font-semibold text-ivory">
            Built on slow mornings
          </h1>
          <p className="mt-6 text-stone">
            Vivek Bori Cafe started with a simple idea: coffee is better when
            there's no rush. Every cup is brewed to order, every dish made
            fresh, and every table is yours for as long as you need it.
          </p>
          <p className="mt-4 text-stone">
            We source our beans carefully, keep the menu honest, and treat
            regulars like family — because most of them are, by now.
          </p>
        </div>
      </div>
    </section>
  );
}
