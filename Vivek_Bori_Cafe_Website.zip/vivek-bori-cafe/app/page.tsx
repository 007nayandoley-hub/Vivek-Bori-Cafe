import Link from "next/link";
import PlaceholderImage from "@/components/PlaceholderImage";

const highlights = [
  {
    name: "Filter Coffee",
    desc: "Slow-brewed, single origin, served black or with warm milk.",
    price: "₹120",
  },
  {
    name: "Cold Brew",
    desc: "18-hour steeped, smooth and low-acid, over ice.",
    price: "₹160",
  },
  {
    name: "Bori Breakfast",
    desc: "Eggs, toast, and a side of our house chutney.",
    price: "₹220",
  },
];

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden px-6 pt-20 pb-28 md:pt-28">
        <div
          className="ring-stain -left-24 -top-16 hidden md:block"
          aria-hidden="true"
        />
        <div
          className="ring-stain bottom-0 right-0 hidden md:block"
          aria-hidden="true"
        />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
          <div>
            <p className="mb-4 text-sm uppercase tracking-[0.2em] text-gold">
              Vivek Bori Cafe
            </p>
            <h1 className="font-display text-4xl font-semibold leading-tight text-ivory md:text-5xl">
              Coffee, slow mornings,
              <br /> and good company.
            </h1>
            <p className="mt-6 max-w-md text-stone">
              A neighbourhood cafe built around honest coffee and food worth
              lingering over. Come as you are, stay as long as you like.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/contact"
                className="focus-ring rounded-full bg-gold px-6 py-3 text-sm font-semibold text-charcoal transition-transform hover:scale-105"
              >
                Reserve a Table
              </Link>
              <Link
                href="/menu"
                className="focus-ring rounded-full border border-white/15 px-6 py-3 text-sm font-medium text-ivory transition-colors hover:border-gold hover:text-gold"
              >
                View Menu
              </Link>
            </div>
          </div>
          <PlaceholderImage
            label="Hero photo — cafe interior, warm morning light"
            className="aspect-[4/5] w-full rounded-2xl"
          />
        </div>
      </section>

      {/* Menu highlights */}
      <section className="border-t border-white/5 bg-surface px-6 py-20">
        <div className="mx-auto max-w-6xl">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] text-gold">
                On the menu
              </p>
              <h2 className="mt-2 font-display text-3xl font-semibold text-ivory">
                A few favourites
              </h2>
            </div>
            <Link
              href="/menu"
              className="focus-ring hidden text-sm text-gold hover:underline md:inline"
            >
              Full menu →
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {highlights.map((item) => (
              <div
                key={item.name}
                className="rounded-xl border border-white/5 bg-charcoal p-6 transition-colors hover:border-gold/30"
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-lg font-semibold text-ivory">
                    {item.name}
                  </h3>
                  <span className="whitespace-nowrap text-gold">
                    {item.price}
                  </span>
                </div>
                <p className="mt-2 text-sm text-stone">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery teaser */}
      <section className="px-6 py-20">
        <div className="mx-auto max-w-6xl">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] text-gold">
                Inside the cafe
              </p>
              <h2 className="mt-2 font-display text-3xl font-semibold text-ivory">
                A look around
              </h2>
            </div>
            <Link
              href="/gallery"
              className="focus-ring hidden text-sm text-gold hover:underline md:inline"
            >
              Full gallery →
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {["Interior", "Coffee bar", "Seating nook", "Signature drink"].map(
              (label) => (
                <PlaceholderImage
                  key={label}
                  label={label}
                  className="aspect-square rounded-xl"
                />
              )
            )}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-white/5 bg-surface px-6 py-20 text-center">
        <div className="mx-auto max-w-2xl">
          <h2 className="font-display text-3xl font-semibold text-ivory">
            Save your table for tonight
          </h2>
          <p className="mt-3 text-stone">
            Message us on WhatsApp or use the form — we'll confirm within the
            hour.
          </p>
          <Link
            href="/contact"
            className="focus-ring mt-8 inline-block rounded-full bg-gold px-8 py-3 text-sm font-semibold text-charcoal transition-transform hover:scale-105"
          >
            Reserve a Table
          </Link>
        </div>
      </section>
    </>
  );
}
