import type { Metadata } from "next";
import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import LocalBusinessSchema from "@/components/LocalBusinessSchema";

// TODO: replace with the live domain once purchased/connected in Netlify
const SITE_URL = "https://vivekboricafe.example.com";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  weight: ["500", "600", "700"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Vivek Bori Cafe | Coffee, Slow Mornings, Good Company",
    template: "%s | Vivek Bori Cafe",
  },
  description:
    "A neighbourhood cafe serving specialty coffee and honest food. Reserve a table, browse the menu, or drop by.",
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
  openGraph: {
    title: "Vivek Bori Cafe",
    description: "Coffee, slow mornings, good company.",
    type: "website",
    url: SITE_URL,
    siteName: "Vivek Bori Cafe",
  },
  twitter: {
    card: "summary_large_image",
    title: "Vivek Bori Cafe",
    description: "Coffee, slow mornings, good company.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${playfair.variable} ${inter.variable}`}>
      <body className="font-body bg-charcoal text-ivory antialiased">
        <LocalBusinessSchema />
        <Navbar />
        <main>{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  );
}
