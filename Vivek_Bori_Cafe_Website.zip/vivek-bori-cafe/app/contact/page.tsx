import type { Metadata } from "next";
import ContactPageClient from "@/components/ContactPageClient";

export const metadata: Metadata = {
  title: "Reserve a Table",
  description:
    "Book your table at Vivek Bori Cafe via WhatsApp or our reservation form. Open daily 8 AM–10 PM.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return <ContactPageClient />;
}
