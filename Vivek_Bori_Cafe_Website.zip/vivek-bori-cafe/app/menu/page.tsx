import type { Metadata } from "next";
import MenuPageClient from "@/components/MenuPageClient";

export const metadata: Metadata = {
  title: "Menu",
  description:
    "Explore our coffee, food, and seasonal specials — from filter coffee to weekend brunch favourites.",
  alternates: { canonical: "/menu" },
};

export default function MenuPage() {
  return <MenuPageClient />;
}
