import Link from "next/link";
import { Coffee } from "lucide-react";

export default function NotFound() {
  return (
    <section className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
      <Coffee size={40} className="text-gold" aria-hidden="true" />
      <h1 className="mt-6 font-display text-3xl font-semibold text-ivory">
        This table isn't set
      </h1>
      <p className="mt-3 max-w-sm text-stone">
        The page you're looking for doesn't exist. Let's get you back to
        something good.
      </p>
      <Link
        href="/"
        className="focus-ring mt-8 rounded-full bg-gold px-6 py-3 text-sm font-semibold text-charcoal transition-transform hover:scale-105"
      >
        Back to Home
      </Link>
    </section>
  );
}
