import type { Metadata } from "next";
import PlaceholderImage from "@/components/PlaceholderImage";

export const metadata: Metadata = {
  title: "Gallery",
  description:
    "A look inside Vivek Bori Cafe — our space, our coffee, our community.",
  alternates: { canonical: "/gallery" },
};

const photos = [
  { label: "Cafe entrance", tall: true },
  { label: "Coffee bar in action", tall: false },
  { label: "Latte art close-up", tall: false },
  { label: "Window seating", tall: true },
  { label: "Bori Breakfast plate", tall: false },
  { label: "Evening ambience", tall: false },
  { label: "Beans & grinder", tall: true },
  { label: "Outdoor patio", tall: false },
];

export default function GalleryPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <p className="text-sm uppercase tracking-[0.2em] text-gold">Gallery</p>
      <h1 className="mt-2 font-display text-4xl font-semibold text-ivory">
        A look around the cafe
      </h1>

      <div className="mt-10 columns-2 gap-4 md:columns-4 [&>*]:mb-4">
        {photos.map((photo) => (
          <PlaceholderImage
            key={photo.label}
            label={photo.label}
            className={`w-full break-inside-avoid rounded-xl ${
              photo.tall ? "aspect-[3/4]" : "aspect-square"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
